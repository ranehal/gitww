import logging
from colorama import Fore
from TwitchChannelPointsMiner import TwitchChannelPointsMiner
from TwitchChannelPointsMiner.logger import LoggerSettings, ColorPalette
from TwitchChannelPointsMiner.classes.Chat import ChatPresence
from TwitchChannelPointsMiner.classes.Discord import Discord
from TwitchChannelPointsMiner.classes.Webhook import Webhook
from TwitchChannelPointsMiner.classes.entities.Bet import Strategy, BetSettings, Condition, OutcomeKeys, FilterCondition, DelayMode
from TwitchChannelPointsMiner.classes.Settings import Priority, Events, FollowersOrder
from TwitchChannelPointsMiner.classes.entities.Streamer import Streamer, StreamerSettings

twitch_miner = TwitchChannelPointsMiner(
    username="mylyfe69",
    password="write-your-secure-psw",
    claim_drops_startup=True,
    priority=[
        Priority.STREAK,
        Priority.ORDER,
        Priority.DROPS
    ],
    enable_analytics=False,
    disable_ssl_cert_verification=False,
    disable_at_in_nickname=True,
    logger_settings=LoggerSettings(
        save=True,
        console_level=logging.INFO,
        console_username=False,
        auto_clear=True,
        time_zone="",
        file_level=logging.DEBUG,
        emoji=False,
        less=True,
        colored=True,
        color_palette=ColorPalette(
            STREAMER_online="GREEN",
            streamer_offline="black",
            GAIN_FOR_RAID=Fore.YELLOW,
            GAIN_FOR_CLAIM=Fore.RED,
            GAIN_FOR_WATCH=Fore.MAGENTA,
            GAIN_FOR_WATCH_STREAK=Fore.CYAN,
            BET_wiN=Fore.MAGENTA
        ),
        discord=Discord(
        webhook_api="https://discord.com/api/webhooks/1383468385110724648/ktmpnSVlf3q7iHLbFWB7g42mvmvHkdJnen6kh6R2W9m8m9jl0WEJFXnkK4DNsJrZ8m1W",
        events=[Events.BET_WIN, Events.BET_LOSE,Events.BET_START, Events.BET_FAILED, Events.BET_GENERAL, Events.STREAMER_ONLINE, Events.STREAMER_OFFLINE,
                Events.CHAT_MENTION,Events.JOIN_RAID,Events.MOMENT_CLAIM,Events.BONUS_CLAIM,Events.GAIN_FOR_CLAIM,Events.GAIN_FOR_WATCH,Events.GAIN_FOR_WATCH_STREAK,Events.BET_LOSE,Events.BET_START,Events.CHAT_MENTION, Events.DROP_CLAIM,Events.BET_WIN,Events.BET_GENERAL],
        ),
    ),
    streamer_settings=StreamerSettings(
        make_predictions=False,
        follow_raid=True,
        claim_drops=True,
        claim_moments=True,
        watch_streak=True,
        chat=ChatPresence.NEVER
    )
)

twitch_miner.analytics(host="0.0.0.0", port=5014, refresh=5, days_ago=90)
twitch_miner.mine(
    [
    
    #cs
"pekswofl",
    
    "heatoncs",
  
    "juaanch1",    
      
    "nooice_1",
  
        
        
    "ShadyyyTV",    
    "xcosmicvapez",
"rackzy","yosoykush",    
    "mitchsgaming",    
    "alex1oiq",    
    "fraximusgaming",    
        
    "chern_ex_",    
    "purplepixie_lol",
"epidemic_cs2",    
    "fumez_ttv",    
        
    "styko",
"sinnexxy",
"FrizzerCS","magilacs","NadeKing",    
      
    
        
    "ErycTriceps",    
    "meastercs",
"dynamicscs2",    
    "KEROVSKI",    
    "olofmeister",    
    "esagcs",    
    "spexyyycs",
"jolyhype",
"elohellpontus",  
    "snaredxxi",  
    "lad_csgo",
"nyqlcs",
"skorpa",    
    "cheating",    
    "queeece",
"lymegreentv",
"wehoopinx",
    
    "futuretroy",    
    "yxngstxr",
"skinravegg",
"ivantuscs",    
    "degentazzz",
"joispoi24",    
    "yxngstxr",    
    "propernator",    
    "maxiedome",
"mump",    
    "jasonr",    
    "gennci",    
    "supr",    
    "9inegg",    
    "biscuit_cs",    
    "haixxd",    
    "vancho666_cs",    
        
        
        
        
    "vitinhocs2",    
    "rassollo",   
    
    
    #cs
"pekswofl",
    
    #gs

"lenxac",
"NervHammr",
"lynn_nooblet",
"hyoukomi",
"evgeny_079",
"rodan354",
"TheNobear",
"xmercurialgg",
"kyle_out",
"MewsicalMiqo",
"cxjealousy",
"FuzzyFoyz",
"FiltratedDig2",
"bawnsii",
"HolySheatM8",
"austinethics",
"solofxrgaming",
"itsAppyyyy",
"jeproxzone",
"zeffyneffy",
"okaidostream",
"Dothedear",
"YunThe2nd",
"Nutellacakee",
"TrevitoGaming",
"1tsally",
"NatDaMonke",
"ladyragnaa",
"jade14th",
"kevzo8",
"rhawr",

    #gs


    #na



    #na   

    
    ],
    followers=False,
    followers_order=FollowersOrder.ASC
)