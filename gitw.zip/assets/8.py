import logging
from colorama import Fore
from TwitchChannelPointsMiner import TwitchChannelPointsMiner
from TwitchChannelPointsMiner.logger import LoggerSettings, ColorPalette
from TwitchChannelPointsMiner.classes.Chat import ChatPresence
from TwitchChannelPointsMiner.classes.Discord import Discord
from TwitchChannelPointsMiner.classes.Webhook import Webhook
from TwitchChannelPointsMiner.classes.entities.Bet import Strategy, BetSettings, Condition, OutcomeKeys, FilterCondition, DelayMode
from TwitchChannelPointsMiner.classes.Settings import Priority, Events, FollowersOrder
from TwitchChannelPointsMiner.classes.entities.Streamer import Streamer, StreamerSettings

twitch_miner = TwitchChannelPointsMiner(
    username="penguinfar8",
    password="write-your-secure-psw",
    claim_drops_startup=True,
    priority=[
        Priority.STREAK,
        Priority.ORDER,
        Priority.DROPS
    ],
    enable_analytics=False,
    disable_ssl_cert_verification=False,
    disable_at_in_nickname=True,
    logger_settings=LoggerSettings(
        save=False,
        console_level=logging.INFO,
        console_username=False,
        auto_clear=True,
        time_zone="",
        file_level=logging.DEBUG,
        emoji=False,
        less=True,
        colored=True,
        color_palette=ColorPalette(
            STREAMER_online="GREEN",
            streamer_offline="black",
            GAIN_FOR_RAID=Fore.YELLOW,
            GAIN_FOR_CLAIM=Fore.RED,
            GAIN_FOR_WATCH=Fore.MAGENTA,
            GAIN_FOR_WATCH_STREAK=Fore.CYAN,
            BET_wiN=Fore.MAGENTA
        ),
        discord=Discord(
        webhook_api="https://discord.com/api/webhooks/1383468176930635796/ILlcfkUmymHyXf9_0vLrSYGx5tphaki00lSCyWH3Dp1nAcn4RRoU02Z9OSa3wtUhKLt9",
        events=[Events.BET_WIN, Events.BET_LOSE,Events.BET_START, Events.BET_FAILED, Events.BET_GENERAL, Events.STREAMER_ONLINE, Events.STREAMER_OFFLINE,
                Events.CHAT_MENTION,Events.JOIN_RAID,Events.MOMENT_CLAIM,Events.BONUS_CLAIM,Events.GAIN_FOR_CLAIM,Events.GAIN_FOR_WATCH,Events.GAIN_FOR_WATCH_STREAK,Events.BET_LOSE,Events.BET_START,Events.CHAT_MENTION, Events.DROP_CLAIM,Events.BET_WIN,Events.BET_GENERAL],
        ),
    ),
    streamer_settings=StreamerSettings(
        make_predictions=False,
        follow_raid=True,
        claim_drops=True,
        claim_moments=True,
        watch_streak=True,
        chat=ChatPresence.ONLINE
    )
)

twitch_miner.analytics(host="0.0.0.0", port=5008, refresh=5, days_ago=30)
twitch_miner.mine(
    [
        "kascs2",
        "9inegg",
"psp1g",
"fraximusgaming",
        "raddabz",
"pekswofl",
        "dynamicscs2",
        "wehoopinx",
        "vancho666_cs",
        Streamer("eryctriceps", settings=StreamerSettings(
            make_predictions=True, community_goals=False,
            bet=BetSettings(
                strategy=Strategy.HIGH_ODDS,
                percentage=1,
                delay_mode=DelayMode.FROM_START,
                delay=180,
                minimum_points=100,
            )
        )),
        "alex1oiq",
"mrtweeday",
        Streamer("skorpa", settings=StreamerSettings(
            make_predictions=True, community_goals=False,
            bet=BetSettings(
                strategy=Strategy.MOST_VOTED,
                percentage=1,
                delay_mode=DelayMode.FROM_END,
                delay=32,
                minimum_points=100,
            )
        )),
        "heatoncs",
        "kerovski",
        "biscuit_cs",
        "mump",
        "ivantuscs",
        "spexyyycs",
"mump",
        "joispoi24",
        "propernator",
        "FrizzerCS",
"magilacs",
        "gennci",
        "jasonr",
        "thecurlyfella",
        "supr",
        "haixxd",
        "olofmeister",
        "yxngstxr",
        "lenxac",
        "nervhammr",
        "lynn_nooblet",
        "hyoukomi",
        "evgeny_079",
        "rodan354",
        "thenobear",
        "xmercurialgg",
        "kyle_out",
        "mewsicalmiqo",
        "cxjealousy",
        "fuzzyfoyz",
        "filtrateddig2",
        "bawnsii",
        "holysheatm8",
        "austinethics",
        "solofxrgaming",
        "itsappyyyy",
        "jeproxzone",
        "zeffyneffy",
        "okaidostream",
        "dothedear",
        "yunthe2nd",
        "nutellacakee",
        "trevitogaming",
        #"1tsally",
        #"NatDaMonke",
        "ladyragnaa",
        "jade14th",
        "kevzo8",
        "rhawr",
    ],
    followers=False,
    followers_order=FollowersOrder.ASC,
)
